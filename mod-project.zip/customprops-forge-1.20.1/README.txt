Custom Props - Forge 1.20.1 (47.3.0)
Build: install Gradle 8.1.1 + JDK 17, then run "gradle build". Jar appears in build/libs/customprops-1.0.0.jar
Or use GitHub Actions (.github/workflows/build.yml).
Item display (hand/GUI size and rotation) can be edited in assets/customprops/models/item/<name>.json
