package com.example.customprops;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CustomProps.MODID)
public class CustomProps {
    public static final String MODID = "customprops";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    private static final String[] PROP_NAMES = {
        "awm",
        "ayran",
        "cajita",
        "nuggets",
        "papas",
        "cigar",
        "refresco",
        "galaxy_s25_ultra",
        "galaxy_s24_ultra",
        "money_gun",
        "turk_lirasi",
        "vape_pen",
        "redmi_12",
        "zippo_lighter"
    };

    public static final List<RegistryObject<Item>> PROPS = new ArrayList<>();

    public static final RegistryObject<Block> BRICK_OVEN = BLOCKS.register("brick_oven",
            () -> new BrickOvenBlock(BlockBehaviour.Properties.of().strength(2.0f).noOcclusion()));
    public static final RegistryObject<Item> BRICK_OVEN_ITEM = ITEMS.register("brick_oven",
            () -> new BlockItem(BRICK_OVEN.get(), new Item.Properties()));

    static {
        for (String n : PROP_NAMES) {
            PROPS.add(ITEMS.register(n, () -> new Item(new Item.Properties().stacksTo(16))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("props", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID))
                    .icon(() -> new ItemStack(PROPS.get(PROPS.size() - 1).get()))
                    .displayItems((params, output) -> {
                        output.accept(BRICK_OVEN_ITEM.get());
                        for (RegistryObject<Item> i : PROPS) output.accept(i.get());
                    })
                    .build());

    public CustomProps() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
